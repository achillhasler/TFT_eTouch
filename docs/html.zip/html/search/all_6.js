var searchData=
[
  ['handletouchcalibrationtarget',['handleTouchCalibrationTarget',['../class_t_f_t__e_touch.html#aec10db7109b2d0cf8cfdc8cd16b12e50',1,'TFT_eTouch']]]
];
