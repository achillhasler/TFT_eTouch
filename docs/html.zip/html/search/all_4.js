var searchData=
[
  ['fetch_5fraw',['fetch_raw',['../class_t_f_t__e_touch_base.html#a36732018de291da64ea0026ae9dc4e8b',1,'TFT_eTouchBase']]]
];
