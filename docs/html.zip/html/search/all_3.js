var searchData=
[
  ['drop_5ffirst_5fmeasures_5f',['drop_first_measures_',['../class_t_f_t__e_touch_base.html#a6cf46a01832d3ee933a5ccc5f164ead2',1,'TFT_eTouchBase']]]
];
