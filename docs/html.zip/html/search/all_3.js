var searchData=
[
  ['data_5f',['data_',['../class_t_f_t__e_touch_gesture.html#a916ec3d61ea9e578ec6343f23182d95a',1,'TFT_eTouchGesture']]],
  ['divisor_5f',['divisor_',['../class_fir_filter.html#a4771c61e819609173ce61d2643733160',1,'FirFilter']]],
  ['drop_5ffirst_5fmeasures_5f',['drop_first_measures_',['../class_t_f_t__e_touch_base.html#a6cf46a01832d3ee933a5ccc5f164ead2',1,'TFT_eTouchBase']]]
];
