var searchData=
[
  ['update_5fallowed_5f',['update_allowed_',['../class_t_f_t__e_touch_base.html#aec75fdcff93794181a3a6a20dbe12bca',1,'TFT_eTouchBase']]]
];
