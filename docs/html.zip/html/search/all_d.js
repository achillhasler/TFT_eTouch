var searchData=
[
  ['q_5f',['q_',['../class_fir_filter.html#a82ef00565f46cf8480730042d908186f',1,'FirFilter']]]
];
