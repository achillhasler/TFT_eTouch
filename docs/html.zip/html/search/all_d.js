var searchData=
[
  ['scr_5fx',['scr_x',['../struct_t_f_t__e_touch_base_1_1_calibration_point.html#ae049eb761ae513688f9344e16bc63338',1,'TFT_eTouchBase::CalibrationPoint']]],
  ['scr_5fy',['scr_y',['../struct_t_f_t__e_touch_base_1_1_calibration_point.html#a4f812157a97acc41cbd7380dd24d94d5',1,'TFT_eTouchBase::CalibrationPoint']]],
  ['set',['set',['../struct_t_f_t__e_touch_base_1_1_touch_point.html#ab82e56d3e55be4934c0ddae8420e1351',1,'TFT_eTouchBase::TouchPoint::set()'],['../struct_t_f_t__e_touch_base_1_1_calibration_point.html#a3d3b42824c167d44dff1af19fea986b7',1,'TFT_eTouchBase::CalibrationPoint::set()']]],
  ['setacuratedistance',['setAcurateDistance',['../class_t_f_t__e_touch_base.html#ad03638874d5435cd0cbca44cdf910028',1,'TFT_eTouchBase']]],
  ['setaveraging',['setAveraging',['../class_t_f_t__e_touch_base.html#af27ee1ad43f0ac00e8d15342f26111cb',1,'TFT_eTouchBase']]],
  ['setcalibration',['setCalibration',['../class_t_f_t__e_touch_base.html#ac170044f0ff389f01e0236e2a4abf056',1,'TFT_eTouchBase']]],
  ['setmeasure',['setMeasure',['../class_t_f_t__e_touch_base.html#a0d59adfe3ef4a523c42fc7cc3b9fbb33',1,'TFT_eTouchBase']]],
  ['setmeasurewait',['setMeasureWait',['../class_t_f_t__e_touch_base.html#a48e8cd9c47f89264d345a3564ed2dccd',1,'TFT_eTouchBase']]],
  ['setrxplate',['setRXPlate',['../class_t_f_t__e_touch_base.html#aa59322af9f05007c31d4933641640278',1,'TFT_eTouchBase']]],
  ['setrzthreshold',['setRZThreshold',['../class_t_f_t__e_touch_base.html#aa9e7ccb2021e79233ffa78b8fb5bc864',1,'TFT_eTouchBase']]],
  ['setvalidrawrange',['setValidRawRange',['../class_t_f_t__e_touch_base.html#a3872ff740aa7b7baf646d672d19973bc',1,'TFT_eTouchBase']]],
  ['spi_5f',['spi_',['../class_t_f_t__e_touch_base.html#a30fb68112d77d0928e904f14ffa48a4a',1,'TFT_eTouchBase']]],
  ['spi_5fend',['spi_end',['../class_t_f_t__e_touch_base.html#afcdc20b45f959cee1ebafe126a949720',1,'TFT_eTouchBase']]],
  ['spi_5fstart',['spi_start',['../class_t_f_t__e_touch_base.html#a910c73ae71c884d3cede7e7d10e500ac',1,'TFT_eTouchBase']]]
];
