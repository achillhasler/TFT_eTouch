var searchData=
[
  ['valid',['valid',['../class_t_f_t__e_touch_base.html#a8209c73832136f000b5c2dfca52b185d',1,'TFT_eTouchBase']]]
];
