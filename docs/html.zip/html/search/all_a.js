var searchData=
[
  ['next',['next',['../class_fir_filter.html#a2afab9e663992c866349155d1f6fdc89',1,'FirFilter']]],
  ['next_5f',['next_',['../class_t_f_t__e_touch_gesture.html#a67db137f4a74291efd30d0024928b719',1,'TFT_eTouchGesture']]],
  ['none',['none',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073a4277e2270eb8d0401ef6a29b7273b327',1,'TFT_eTouchGesture']]]
];
