var searchData=
[
  ['next_5f',['next_',['../class_t_f_t__e_touch_gesture.html#a67db137f4a74291efd30d0024928b719',1,'TFT_eTouchGesture']]]
];
