var searchData=
[
  ['stay',['stay',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073ab3397f2a0efd5709e9f179e4daac38e7',1,'TFT_eTouchGesture']]]
];
