var searchData=
[
  ['waitpenup',['waitPenUp',['../class_t_f_t__e_touch_base.html#a215e4623fa880f1ec6caf36c4494cd7e',1,'TFT_eTouchBase']]],
  ['wipe',['wipe',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073ae736953f201ae983a89258e23ecb689c',1,'TFT_eTouchGesture']]],
  ['writecalibration',['writeCalibration',['../class_t_f_t__e_touch_base.html#acc22bdb047c4ae4985c8b1de6806067c',1,'TFT_eTouchBase']]]
];
