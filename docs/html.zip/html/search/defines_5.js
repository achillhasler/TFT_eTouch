var searchData=
[
  ['z1_5fmeasure',['Z1_MEASURE',['../_t_f_t__e_touch_base_8cpp.html#a83fbc276c6f0bb44a1bea2012dbf4fbb',1,'TFT_eTouchBase.cpp']]],
  ['z1_5fmeasure_5fdfr',['Z1_MEASURE_DFR',['../_t_f_t__e_touch_base_8cpp.html#a4bd196efe5ed82ce43b3a1945c41686d',1,'TFT_eTouchBase.cpp']]],
  ['z1_5fmeasure_5fser',['Z1_MEASURE_SER',['../_t_f_t__e_touch_base_8cpp.html#a7ca871a307cdbd8677c55d632d771438',1,'TFT_eTouchBase.cpp']]],
  ['z2_5fmeasure',['Z2_MEASURE',['../_t_f_t__e_touch_base_8cpp.html#a4a807ce782959270261feeb79d2b459c',1,'TFT_eTouchBase.cpp']]],
  ['z2_5fmeasure_5fdfr',['Z2_MEASURE_DFR',['../_t_f_t__e_touch_base_8cpp.html#a6a875125544d7a47a2e0127efe6d1be2',1,'TFT_eTouchBase.cpp']]],
  ['z2_5fmeasure_5fser',['Z2_MEASURE_SER',['../_t_f_t__e_touch_base_8cpp.html#aca00c119e23da87d45eec069a9404432',1,'TFT_eTouchBase.cpp']]]
];
