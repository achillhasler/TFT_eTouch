var searchData=
[
  ['calibation_5f',['calibation_',['../class_t_f_t__e_touch_base.html#a5564256163ab114676d715072726ca1c',1,'TFT_eTouchBase']]],
  ['count_5fmeasure_5f',['count_measure_',['../class_t_f_t__e_touch_base.html#a8d829821428526331acbad783e371e52',1,'TFT_eTouchBase']]],
  ['cs_5f',['cs_',['../class_t_f_t__e_touch_base.html#abd326990fe30a478318b77398ccc1685',1,'TFT_eTouchBase']]]
];
