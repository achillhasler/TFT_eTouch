var searchData=
[
  ['update',['update',['../class_t_f_t__e_touch_base.html#ab403860de0e9d5a2a1864a311b708bc9',1,'TFT_eTouchBase']]]
];
