var searchData=
[
  ['wipe',['wipe',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073ae736953f201ae983a89258e23ecb689c',1,'TFT_eTouchGesture']]]
];
