var searchData=
[
  ['_7etft_5fetouchgesture',['~TFT_eTouchGesture',['../class_t_f_t__e_touch_gesture.html#a04ef1c9f70637566f54c88cfc52810aa',1,'TFT_eTouchGesture']]]
];
