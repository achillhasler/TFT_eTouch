var searchData=
[
  ['raw_5f',['raw_',['../class_t_f_t__e_touch_base.html#a28e545faf1e025d70b04e61fa2aaa35c',1,'TFT_eTouchBase']]],
  ['raw_5fvalid_5fmax_5f',['raw_valid_max_',['../class_t_f_t__e_touch_base.html#a50a61299904f458569ed9f38b79195bc',1,'TFT_eTouchBase']]],
  ['raw_5fvalid_5fmin_5f',['raw_valid_min_',['../class_t_f_t__e_touch_base.html#ad767e44c8bfa6dec28d67ccf6685e55c',1,'TFT_eTouchBase']]],
  ['readcalibration',['readCalibration',['../class_t_f_t__e_touch_base.html#aae7550603802b9ca985731e0d7acb6f6',1,'TFT_eTouchBase']]],
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['rel_5frotation',['rel_rotation',['../struct_t_f_t__e_touch_base_1_1_calibation.html#a6b0a8db1cc9773f7d6f8ad254a98d11a',1,'TFT_eTouchBase::Calibation']]],
  ['reset',['reset',['../class_fir_filter.html#a5d956048be46dab55f5e6aeb5b001ff9',1,'FirFilter::reset()'],['../class_t_f_t__e_touch_base.html#acc7d91084bc8b6629e6b8c011bd2c8b1',1,'TFT_eTouchBase::reset()'],['../class_t_f_t__e_touch_gesture.html#a1be9ffc2c975f7cd4f6c9670c89c38ea',1,'TFT_eTouchGesture::reset()']]],
  ['rx_5fplate_5f',['rx_plate_',['../class_t_f_t__e_touch_base.html#abdc21d600f959e5318c3e9502daa1cd1',1,'TFT_eTouchBase']]],
  ['rz',['rz',['../struct_t_f_t__e_touch_base_1_1_measure.html#ab380409eae4d8b1d3b3615acd8c109cb',1,'TFT_eTouchBase::Measure::rz()'],['../struct_t_f_t__e_touch_base_1_1_touch_point.html#a72548bce3d78a36be2d4f5f9987740a4',1,'TFT_eTouchBase::TouchPoint::rz()'],['../struct_t_f_t__e_touch_gesture_1_1_filtered_measure.html#a94701aaa5ff7af0b9ff323909f08ab7e',1,'TFT_eTouchGesture::FilteredMeasure::rz()']]],
  ['rz_5fthreshold_5f',['rz_threshold_',['../class_t_f_t__e_touch_base.html#ab152ed60b115623afc47a487564cba57',1,'TFT_eTouchBase']]]
];
