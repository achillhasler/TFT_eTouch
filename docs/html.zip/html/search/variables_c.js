var searchData=
[
  ['scr_5fx',['scr_x',['../struct_t_f_t__e_touch_base_1_1_calibration_point.html#ae049eb761ae513688f9344e16bc63338',1,'TFT_eTouchBase::CalibrationPoint']]],
  ['scr_5fy',['scr_y',['../struct_t_f_t__e_touch_base_1_1_calibration_point.html#a4f812157a97acc41cbd7380dd24d94d5',1,'TFT_eTouchBase::CalibrationPoint']]],
  ['size_5f',['size_',['../class_t_f_t__e_touch_gesture.html#a8ea815bf8479670b79e348a71ebb979f',1,'TFT_eTouchGesture']]],
  ['spi_5f',['spi_',['../class_t_f_t__e_touch_base.html#a30fb68112d77d0928e904f14ffa48a4a',1,'TFT_eTouchBase']]]
];
