var searchData=
[
  ['y',['y',['../struct_t_f_t__e_touch_base_1_1_measure.html#a97813cd501a1a86962cca446145f6109',1,'TFT_eTouchBase::Measure::y()'],['../struct_t_f_t__e_touch_base_1_1_touch_point.html#a993e06881403fc32915ffa5bc441864b',1,'TFT_eTouchBase::TouchPoint::y()']]],
  ['y0',['y0',['../struct_t_f_t__e_touch_base_1_1_calibation.html#afd39584dfbbe2a0e14731f45410bf013',1,'TFT_eTouchBase::Calibation']]],
  ['y1',['y1',['../struct_t_f_t__e_touch_base_1_1_calibation.html#a3d8bb98ad6c8dacef1adf5e0519ffc06',1,'TFT_eTouchBase::Calibation']]]
];
