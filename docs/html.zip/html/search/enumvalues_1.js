var searchData=
[
  ['none',['none',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073a4277e2270eb8d0401ef6a29b7273b327',1,'TFT_eTouchGesture']]]
];
