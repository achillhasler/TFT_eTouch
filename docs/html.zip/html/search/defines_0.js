var searchData=
[
  ['basic_5ffont_5fsupport',['BASIC_FONT_SUPPORT',['../_t_f_t__e_touch_user_8h.html#acd1902910e8ccd307604055e89b73455',1,'TFT_eTouchUser.h']]]
];
