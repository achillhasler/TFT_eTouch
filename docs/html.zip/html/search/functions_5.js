var searchData=
[
  ['measure',['Measure',['../struct_t_f_t__e_touch_base_1_1_measure.html#a88dae72548c81cac5b8340e60db7d8b2',1,'TFT_eTouchBase::Measure']]]
];
