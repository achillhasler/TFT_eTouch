var searchData=
[
  ['move',['move',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073a0c30a234744ebb6472f015e9aa139240',1,'TFT_eTouchGesture']]]
];
