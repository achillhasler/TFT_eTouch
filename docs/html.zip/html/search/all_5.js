var searchData=
[
  ['get',['get',['../class_t_f_t__e_touch.html#adbfe7a0acefc9371bfaf17c0f5662e3b',1,'TFT_eTouch::get()'],['../class_t_f_t__e_touch_gesture.html#ad0562bc84e3e100ef359898502829f41',1,'TFT_eTouchGesture::get()']]],
  ['getacuratedistance',['getAcurateDistance',['../class_t_f_t__e_touch_base.html#af3db895503dbc3be28a70e5c2c019487',1,'TFT_eTouchBase']]],
  ['getmeasurewait',['getMeasureWait',['../class_t_f_t__e_touch_base.html#a6276395e91bda8a2481430fca3c3a5ff',1,'TFT_eTouchBase']]],
  ['getraw',['getRaw',['../class_t_f_t__e_touch_base.html#acaa03c78893d1a9d1cced208685df379',1,'TFT_eTouchBase::getRaw(uint16_t &amp;x, uint16_t &amp;y, uint16_t &amp;z1, uint16_t &amp;z2, uint16_t &amp;rz)'],['../class_t_f_t__e_touch_base.html#ad2e0d5a712abd2d7ef1d08e0d1412ad8',1,'TFT_eTouchBase::getRaw(Measure &amp;raw)']]],
  ['getrxplate',['getRXPlate',['../class_t_f_t__e_touch_base.html#a93148b756964d4ce57ba9f59600775a6',1,'TFT_eTouchBase']]],
  ['getrz',['getRZ',['../class_t_f_t__e_touch_base.html#a4e208e87ff8c0f90d5978ed0c713618a',1,'TFT_eTouchBase']]],
  ['getrzthreshold',['getRZThreshold',['../class_t_f_t__e_touch_base.html#a3b4eaa76d1f902d51e61b173e7858ed3',1,'TFT_eTouchBase']]],
  ['getusercalibration',['getUserCalibration',['../class_t_f_t__e_touch.html#a10b5cb26b29314b3584ee816a54aa6c1',1,'TFT_eTouch']]],
  ['getxy',['getXY',['../class_t_f_t__e_touch.html#a301b7de160f46507b00605c72b6189b9',1,'TFT_eTouch']]]
];
