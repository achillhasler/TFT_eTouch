var searchData=
[
  ['x_5fmeasure',['X_MEASURE',['../_t_f_t__e_touch_base_8cpp.html#aae1e54d0f3d79bfae159b14a6bce62fd',1,'TFT_eTouchBase.cpp']]],
  ['x_5fmeasure_5fdfr',['X_MEASURE_DFR',['../_t_f_t__e_touch_base_8cpp.html#a27187936c5afcedf2b16427c19164e2a',1,'TFT_eTouchBase.cpp']]],
  ['x_5fmeasure_5fser',['X_MEASURE_SER',['../_t_f_t__e_touch_base_8cpp.html#a1f6b3bb6783ff47e972d3e9c2e811d42',1,'TFT_eTouchBase.cpp']]]
];
