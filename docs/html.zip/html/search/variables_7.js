var searchData=
[
  ['raw_5f',['raw_',['../class_t_f_t__e_touch_base.html#a28e545faf1e025d70b04e61fa2aaa35c',1,'TFT_eTouchBase']]],
  ['raw_5fvalid_5fmax_5f',['raw_valid_max_',['../class_t_f_t__e_touch_base.html#a50a61299904f458569ed9f38b79195bc',1,'TFT_eTouchBase']]],
  ['raw_5fvalid_5fmin_5f',['raw_valid_min_',['../class_t_f_t__e_touch_base.html#ad767e44c8bfa6dec28d67ccf6685e55c',1,'TFT_eTouchBase']]],
  ['rel_5frotation',['rel_rotation',['../struct_t_f_t__e_touch_base_1_1_calibation.html#a6b0a8db1cc9773f7d6f8ad254a98d11a',1,'TFT_eTouchBase::Calibation']]],
  ['rx_5fplate_5f',['rx_plate_',['../class_t_f_t__e_touch_base.html#abdc21d600f959e5318c3e9502daa1cd1',1,'TFT_eTouchBase']]],
  ['rz',['rz',['../struct_t_f_t__e_touch_base_1_1_measure.html#ab380409eae4d8b1d3b3615acd8c109cb',1,'TFT_eTouchBase::Measure::rz()'],['../struct_t_f_t__e_touch_base_1_1_touch_point.html#a72548bce3d78a36be2d4f5f9987740a4',1,'TFT_eTouchBase::TouchPoint::rz()']]],
  ['rz_5fthreshold_5f',['rz_threshold_',['../class_t_f_t__e_touch_base.html#ab152ed60b115623afc47a487564cba57',1,'TFT_eTouchBase']]]
];
