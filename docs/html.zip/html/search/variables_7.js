var searchData=
[
  ['measure_5fwait_5fms_5f',['measure_wait_ms_',['../class_t_f_t__e_touch_base.html#ac2209f821e5ecd7aa2bc454ffad69a46',1,'TFT_eTouchBase']]],
  ['ms',['ms',['../struct_t_f_t__e_touch_gesture_1_1_filtered_measure.html#afb533bc4935322f6ff6edf02e4e9b640',1,'TFT_eTouchGesture::FilteredMeasure']]]
];
