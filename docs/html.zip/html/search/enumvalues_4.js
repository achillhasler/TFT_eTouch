var searchData=
[
  ['zoom_5fin',['zoom_in',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073a6fc5141d3666adfb1bdfdebc85dee959',1,'TFT_eTouchGesture']]],
  ['zoom_5fout',['zoom_out',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073a6be1942619a8ed93ee2cb93bbc788c08',1,'TFT_eTouchGesture']]]
];
