var searchData=
[
  ['update',['update',['../class_t_f_t__e_touch_base.html#ab403860de0e9d5a2a1864a311b708bc9',1,'TFT_eTouchBase']]],
  ['update_5fallowed_5f',['update_allowed_',['../class_t_f_t__e_touch_base.html#aec75fdcff93794181a3a6a20dbe12bca',1,'TFT_eTouchBase']]]
];
