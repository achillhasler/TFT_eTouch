var searchData=
[
  ['act_5f',['act_',['../class_fir_filter.html#a66e610d63f13eb117b00bf6110c52360',1,'FirFilter']]],
  ['action',['Action',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073',1,'TFT_eTouchGesture']]],
  ['acurate_5fdifference_5f',['acurate_difference_',['../class_t_f_t__e_touch_base.html#ab04417e729b7d05a0c1b8a989c326e42',1,'TFT_eTouchBase']]],
  ['acuratecalibrationtarget',['acurateCalibrationTarget',['../class_t_f_t__e_touch_base.html#a2516fde29b683209caac3236df9e499c',1,'TFT_eTouchBase']]],
  ['averaging_5fmeasure_5f',['averaging_measure_',['../class_t_f_t__e_touch_base.html#a1850d0943134e9563d0669492b25aa40',1,'TFT_eTouchBase']]]
];
