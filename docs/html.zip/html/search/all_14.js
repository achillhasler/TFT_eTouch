var searchData=
[
  ['x',['x',['../struct_t_f_t__e_touch_base_1_1_measure.html#a4eb66b0bd6ac42056e905ab3fd8601de',1,'TFT_eTouchBase::Measure::x()'],['../struct_t_f_t__e_touch_base_1_1_touch_point.html#a5aea92cbccb6d0f2fe83211630000072',1,'TFT_eTouchBase::TouchPoint::x()'],['../struct_t_f_t__e_touch_gesture_1_1_filtered_measure.html#afcb233e8d6ac03e41ed8b2a97a7b52d4',1,'TFT_eTouchGesture::FilteredMeasure::x()']]],
  ['x0',['x0',['../struct_t_f_t__e_touch_base_1_1_calibation.html#a2c580b3df77a3a8960c0c888b2ca6946',1,'TFT_eTouchBase::Calibation']]],
  ['x1',['x1',['../struct_t_f_t__e_touch_base_1_1_calibation.html#ad4db4169355a5b599840166e619acc67',1,'TFT_eTouchBase::Calibation']]],
  ['x_5fmeasure',['X_MEASURE',['../_t_f_t__e_touch_base_8cpp.html#aae1e54d0f3d79bfae159b14a6bce62fd',1,'TFT_eTouchBase.cpp']]],
  ['x_5fmeasure_5fdfr',['X_MEASURE_DFR',['../_t_f_t__e_touch_base_8cpp.html#a27187936c5afcedf2b16427c19164e2a',1,'TFT_eTouchBase.cpp']]],
  ['x_5fmeasure_5fser',['X_MEASURE_SER',['../_t_f_t__e_touch_base_8cpp.html#a1f6b3bb6783ff47e972d3e9c2e811d42',1,'TFT_eTouchBase.cpp']]]
];
