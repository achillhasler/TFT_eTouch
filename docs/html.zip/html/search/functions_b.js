var searchData=
[
  ['readcalibration',['readCalibration',['../class_t_f_t__e_touch_base.html#aae7550603802b9ca985731e0d7acb6f6',1,'TFT_eTouchBase']]],
  ['reset',['reset',['../class_fir_filter.html#a5d956048be46dab55f5e6aeb5b001ff9',1,'FirFilter::reset()'],['../class_t_f_t__e_touch_base.html#acc7d91084bc8b6629e6b8c011bd2c8b1',1,'TFT_eTouchBase::reset()'],['../class_t_f_t__e_touch_gesture.html#a1be9ffc2c975f7cd4f6c9670c89c38ea',1,'TFT_eTouchGesture::reset()']]]
];
