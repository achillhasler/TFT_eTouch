var searchData=
[
  ['tft_5fetouch',['TFT_eTouch',['../index.html',1,'']]],
  ['tft_5fetouch',['TFT_eTouch',['../md__c_1__users_achil__documents__arduino_libraries__t_f_t_e_touch__r_e_a_d_m_e.html',1,'']]]
];
