var searchData=
[
  ['ignore_5fmin_5fmax_5fmeasure_5f',['ignore_min_max_measure_',['../class_t_f_t__e_touch_base.html#af8701a587530b7c36978f93646219f97',1,'TFT_eTouchBase']]],
  ['isr_5finstance_5f',['isr_instance_',['../class_t_f_t__e_touch.html#a297c1bb882145cfae66bb7032bfc6e42',1,'TFT_eTouch']]]
];
