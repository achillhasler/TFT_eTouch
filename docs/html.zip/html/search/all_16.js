var searchData=
[
  ['z1',['z1',['../struct_t_f_t__e_touch_base_1_1_measure.html#a03c715eb359a04ee094a563acc702e56',1,'TFT_eTouchBase::Measure::z1()'],['../struct_t_f_t__e_touch_gesture_1_1_filtered_measure.html#a16e22c04308cb174bea261049fc009a2',1,'TFT_eTouchGesture::FilteredMeasure::z1()']]],
  ['z1_5fmeasure',['Z1_MEASURE',['../_t_f_t__e_touch_base_8cpp.html#a83fbc276c6f0bb44a1bea2012dbf4fbb',1,'TFT_eTouchBase.cpp']]],
  ['z1_5fmeasure_5fdfr',['Z1_MEASURE_DFR',['../_t_f_t__e_touch_base_8cpp.html#a4bd196efe5ed82ce43b3a1945c41686d',1,'TFT_eTouchBase.cpp']]],
  ['z1_5fmeasure_5fser',['Z1_MEASURE_SER',['../_t_f_t__e_touch_base_8cpp.html#a7ca871a307cdbd8677c55d632d771438',1,'TFT_eTouchBase.cpp']]],
  ['z2',['z2',['../struct_t_f_t__e_touch_base_1_1_measure.html#af9c164a0681e5d1022ab22ea02a5ca2c',1,'TFT_eTouchBase::Measure::z2()'],['../struct_t_f_t__e_touch_gesture_1_1_filtered_measure.html#aa6fc840793daea371dc855a67c91b8b5',1,'TFT_eTouchGesture::FilteredMeasure::z2()']]],
  ['z2_5fmeasure',['Z2_MEASURE',['../_t_f_t__e_touch_base_8cpp.html#a4a807ce782959270261feeb79d2b459c',1,'TFT_eTouchBase.cpp']]],
  ['z2_5fmeasure_5fdfr',['Z2_MEASURE_DFR',['../_t_f_t__e_touch_base_8cpp.html#a6a875125544d7a47a2e0127efe6d1be2',1,'TFT_eTouchBase.cpp']]],
  ['z2_5fmeasure_5fser',['Z2_MEASURE_SER',['../_t_f_t__e_touch_base_8cpp.html#aca00c119e23da87d45eec069a9404432',1,'TFT_eTouchBase.cpp']]],
  ['z_5ffirst_5fmeasure_5f',['z_first_measure_',['../class_t_f_t__e_touch_base.html#acd6a21a8efc15cde77ca876fa75890c5',1,'TFT_eTouchBase']]],
  ['z_5flocal_5fmin_5fmeasure_5f',['z_local_min_measure_',['../class_t_f_t__e_touch_base.html#a41168d9251c481ef7fd47f087e5f7fae',1,'TFT_eTouchBase']]],
  ['z_5fonce_5fmeasure_5f',['z_once_measure_',['../class_t_f_t__e_touch_base.html#a9f4735e87d34709dc84c5e79901e5602',1,'TFT_eTouchBase']]],
  ['zoom_5fin',['zoom_in',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073a6fc5141d3666adfb1bdfdebc85dee959',1,'TFT_eTouchGesture']]],
  ['zoom_5fout',['zoom_out',['../class_t_f_t__e_touch_gesture.html#afa75bd21441ab47253058de4687da073a6be1942619a8ed93ee2cb93bbc788c08',1,'TFT_eTouchGesture']]]
];
