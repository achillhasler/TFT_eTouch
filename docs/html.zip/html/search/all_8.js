var searchData=
[
  ['last_5fmeasure_5ftime_5fus_5f',['last_measure_time_us_',['../class_t_f_t__e_touch_base.html#a1488b2df699eb4b02681ec6885621a93',1,'TFT_eTouchBase']]]
];
