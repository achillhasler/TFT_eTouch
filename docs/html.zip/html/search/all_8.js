var searchData=
[
  ['last_5fmeasure_5ftime_5fms_5f',['last_measure_time_ms_',['../class_t_f_t__e_touch_base.html#a6a92d9a23116aed40306a9aa4fc456a2',1,'TFT_eTouchBase']]]
];
