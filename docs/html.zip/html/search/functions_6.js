var searchData=
[
  ['in_5frange',['in_range',['../class_t_f_t__e_touch_base.html#a0fd8f37cbced66621f3a53dcbed78b01',1,'TFT_eTouchBase']]],
  ['init',['init',['../class_t_f_t__e_touch.html#a848cc96543aa35d11906b9e91a35d8d7',1,'TFT_eTouch::init()'],['../class_t_f_t__e_touch_base.html#a0993715baf5c6fed85cbd6b8628f4537',1,'TFT_eTouchBase::init()']]],
  ['is_5ftouched',['is_touched',['../class_t_f_t__e_touch_base.html#aa982795e4ef3d70c3a2068b5bbcb410a',1,'TFT_eTouchBase']]]
];
