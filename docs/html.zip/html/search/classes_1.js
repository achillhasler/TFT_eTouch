var searchData=
[
  ['measure',['Measure',['../struct_t_f_t__e_touch_base_1_1_measure.html',1,'TFT_eTouchBase']]]
];
