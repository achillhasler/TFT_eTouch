var searchData=
[
  ['act_5f',['act_',['../class_fir_filter.html#a66e610d63f13eb117b00bf6110c52360',1,'FirFilter']]],
  ['acurate_5fdifference_5f',['acurate_difference_',['../class_t_f_t__e_touch_base.html#ab04417e729b7d05a0c1b8a989c326e42',1,'TFT_eTouchBase']]],
  ['averaging_5fmeasure_5f',['averaging_measure_',['../class_t_f_t__e_touch_base.html#a1850d0943134e9563d0669492b25aa40',1,'TFT_eTouchBase']]]
];
