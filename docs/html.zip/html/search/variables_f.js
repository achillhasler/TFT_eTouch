var searchData=
[
  ['x',['x',['../struct_t_f_t__e_touch_base_1_1_measure.html#a4eb66b0bd6ac42056e905ab3fd8601de',1,'TFT_eTouchBase::Measure::x()'],['../struct_t_f_t__e_touch_base_1_1_touch_point.html#a5aea92cbccb6d0f2fe83211630000072',1,'TFT_eTouchBase::TouchPoint::x()'],['../struct_t_f_t__e_touch_gesture_1_1_filtered_measure.html#afcb233e8d6ac03e41ed8b2a97a7b52d4',1,'TFT_eTouchGesture::FilteredMeasure::x()']]],
  ['x0',['x0',['../struct_t_f_t__e_touch_base_1_1_calibation.html#a2c580b3df77a3a8960c0c888b2ca6946',1,'TFT_eTouchBase::Calibation']]],
  ['x1',['x1',['../struct_t_f_t__e_touch_base_1_1_calibation.html#ad4db4169355a5b599840166e619acc67',1,'TFT_eTouchBase::Calibation']]]
];
