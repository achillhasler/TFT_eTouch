var searchData=
[
  ['basic_5ffont_5fsupport',['BASIC_FONT_SUPPORT',['../_t_f_t__e_touch_user_8h.html#acd1902910e8ccd307604055e89b73455',1,'TFT_eTouchUser.h']]],
  ['begin',['begin',['../class_t_f_t__e_touch.html#a27fa0ae829e083686ddb1a5b8f201167',1,'TFT_eTouch']]],
  ['buffer_5f',['buffer_',['../class_fir_filter.html#ac55b93c8b43a932ab89008e7f7954825',1,'FirFilter']]]
];
