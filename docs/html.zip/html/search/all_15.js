var searchData=
[
  ['y',['y',['../struct_t_f_t__e_touch_base_1_1_measure.html#a97813cd501a1a86962cca446145f6109',1,'TFT_eTouchBase::Measure::y()'],['../struct_t_f_t__e_touch_base_1_1_touch_point.html#a993e06881403fc32915ffa5bc441864b',1,'TFT_eTouchBase::TouchPoint::y()'],['../struct_t_f_t__e_touch_gesture_1_1_filtered_measure.html#a4ae02e1b8d808c4bda4ddb80a111eaf8',1,'TFT_eTouchGesture::FilteredMeasure::y()']]],
  ['y0',['y0',['../struct_t_f_t__e_touch_base_1_1_calibation.html#afd39584dfbbe2a0e14731f45410bf013',1,'TFT_eTouchBase::Calibation']]],
  ['y1',['y1',['../struct_t_f_t__e_touch_base_1_1_calibation.html#a3d8bb98ad6c8dacef1adf5e0519ffc06',1,'TFT_eTouchBase::Calibation']]],
  ['y_5fmeasure',['Y_MEASURE',['../_t_f_t__e_touch_base_8cpp.html#a73a797f3aec64b7129f72896b6674cf9',1,'TFT_eTouchBase.cpp']]],
  ['y_5fmeasure_5fdfr',['Y_MEASURE_DFR',['../_t_f_t__e_touch_base_8cpp.html#a59da7d6b7478f88a79b1f327dd7ee16a',1,'TFT_eTouchBase.cpp']]],
  ['y_5fmeasure_5fser',['Y_MEASURE_SER',['../_t_f_t__e_touch_base_8cpp.html#a8fcef7bc4f6959a0869f35ca3b7333c3',1,'TFT_eTouchBase.cpp']]]
];
