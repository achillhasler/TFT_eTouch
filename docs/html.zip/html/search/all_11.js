var searchData=
[
  ['waitpenup',['waitPenUp',['../class_t_f_t__e_touch_base.html#a215e4623fa880f1ec6caf36c4494cd7e',1,'TFT_eTouchBase']]],
  ['writecalibration',['writeCalibration',['../class_t_f_t__e_touch_base.html#acc22bdb047c4ae4985c8b1de6806067c',1,'TFT_eTouchBase']]]
];
